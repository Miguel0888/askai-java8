# vision-processing

Eigenständiges Java-8-Modul für eine spätere AskAI-Integration. Es ergänzt die vorhandene Audio-DSP-Idee um eine **Vision-/Video-Pipeline** für Live-MJPEG, Batch-Videos, klassische Bildverarbeitung und AI-Inferenz.

Das Modul enthält bewusst **keine konkrete ONNX-/DirectML-Runtime**. Stattdessen sind `ObjectDetector` und `ImageClassifier` Ports. Claude kann später AskAIs lokale Modell-Runtime bzw. einen Java-21-Sidecar daran anbinden. Dadurch bleibt dieses Modul Java 8 und unabhängig von Ollama, ONNX Runtime oder Windows-spezifischen APIs.

## Step 1 – zuerst die XIAO-Kamera anbinden

**Das ist der erste Integrationsschritt. Noch keine AI einbauen, bevor dieser Test grün ist.**

Der XIAO ESP32-S3 liefert den MJPEG-Stream unter:

```text
http://xiao-setup.local:81/stream
```

`MjpegHttpFrameSource` verbindet sich mit diesem Endpoint und liefert jedes JPEG als `VisionFrame`/`BufferedImage`.

Standalone-Test:

```bash
./gradlew cameraProbe
```

oder mit expliziter URL/IP:

```bash
./gradlew cameraProbe -PstreamUrl=http://172.17.1.26:81/stream
```

Erwartung:

```text
Connecting to MJPEG camera: http://xiao-setup.local:81/stream
Frame received: 800x600
Saved: .../camera-probe.jpg
```

Claude soll bei der AskAI-Integration zuerst einen kleinen manuellen UI-/Service-Test bauen, der `MjpegHttpFrameSource` öffnet und die empfangenen `BufferedImage`-Frames anzeigt. **Erst wenn der Live-Stream stabil läuft, weitere Pipeline-Blöcke integrieren.**

## Zielarchitektur

```text
Live camera / video file
        |
        v
VideoFrameSource
  |-- MjpegHttpFrameSource       (XIAO live)
  `-- JCodecVideoFileFrameSource (MP4 batch)
        |
        v
FrameSampler
        |
        v
VisionProcessingPipeline
  |-- ResizeProcessor
  |-- GrayscaleProcessor
  `-- ContrastProcessor
        |
        +--> FrameDifferenceMotionAnalyzer  (classic CV/DSP)
        |
        +--> ObjectDetector                 (AI port)
        |
        `--> ImageClassifier                (optional AI port)
                 |
                 v
          VideoAnalysisResult
                 |
                 v
          ResultSink / AskAI UI
```

## Warum Object Detection nicht einfach Ollama/GGUF ist

AskAI kann bereits Hugging-Face-Modelle als GGUF für Ollama installieren. Das ist für VLMs und semantische Bildanalyse wertvoll, aber `vision` bedeutet nur **Bild als Eingabe**. Es garantiert keine deterministischen Bounding Boxes.

Für Video-Batch und Tracking soll AskAI zwei Modellfähigkeiten trennen:

```text
VISION                  Bild kann vom Modell verstanden werden (z.B. VLM/Ollama)
OBJECT_DETECTION        Modell liefert Klassen + Confidence + Bounding Boxes
IMAGE_CLASSIFICATION    Modell klassifiziert das Gesamtbild
```

Empfohlener Detection-Pfad:

```text
Hugging Face model.onnx (z.B. YOLOv8n/YOLO11n)
        |
        v
AskAI local vision runtime / DirectML adapter
        |
        v
ObjectDetector
```

Optional danach:

```text
Detection ROI / interessanter Frame
        |
        v
Ollama VLM / GGUF
        |
        v
semantische Beschreibung
```

So läuft das kleine Detector-Modell auf vielen Frames, während ein großes VLM nur gezielt auf relevante Frames/ROIs angewendet wird.

## Enthaltene Bausteine

### Domain

- `VisionFrame` – Index, Zeitstempel, `BufferedImage`
- `BoundingBox`
- `Detection`
- `Classification`
- `MotionAnalysis`
- `VideoAnalysisResult`

### Videoquellen

- `VideoFrameSource` – SPI
- `MjpegHttpFrameSource` – HTTP-MJPEG, standardmäßig XIAO URL
- `JCodecVideoFileFrameSource` – MP4/H.264-artige Batchquellen über JCodec 0.2.5

JCodec ist bewusst hinter `VideoFrameSource` gekapselt. AskAI kennt im Application-/Domain-Code keine JCodec-Klassen.

### DSP / klassische Bildverarbeitung

- `VisionFrameProcessor` – austauschbarer Processing-Block
- `VisionProcessingPipeline` – geordnete Pipeline
- `ResizeProcessor`
- `GrayscaleProcessor`
- `ContrastProcessor`
- `FrameDifferenceMotionAnalyzer` – einfache Bewegungsdetektion ohne AI

Weitere Blöcke (Sharpen, Blur, Histogramm, CLAHE, Background subtraction etc.) werden als neue Implementierungen ergänzt, ohne die Pipeline zu ändern.

### AI Ports

```java
public interface ObjectDetector {
    List<Detection> detect(VisionFrame frame) throws VisionInferenceException;
}

public interface ImageClassifier {
    List<Classification> classify(VisionFrame frame) throws VisionInferenceException;
}
```

Die Ports gehören fachlich zur Vision-Schicht. Eine konkrete DirectML-/ONNX-/Ollama-Implementierung gehört in ein Adapter-/Runtime-Modul.

### YOLO-Helfer

- `RgbNchwTensorPreprocessor` erzeugt einen RGB-Float-NCHW-Tensor mit Letterboxing.
- `TensorImage` trägt Scale/Padding für die Rücktransformation.
- `YoloDetectionDecoder` dekodiert klassische YOLOv8/YOLO11-Ausgaben und führt class-aware NMS durch.
- `Coco80Labels` enthält die 80 COCO-Klassen.

Der Decoder ist Runtime-neutral. Ein späterer DirectML-Adapter muss nur den ONNX-Output als `float[]` plus Shape liefern.

## Batchverarbeitung

`VideoBatchAnalysisService` orchestriert nur:

```text
read frame -> sample -> DSP -> motion -> detector -> classifier -> sink
```

Es kennt weder UI noch konkrete Inferenzruntime.

Beispiel für Offline-Video:

```java
VideoFrameSource source = new JCodecVideoFileFrameSource(new File("input.mp4"));
VideoAnalysisResultSink sink = new JsonLinesResultSink(new File("result.jsonl"));

VideoBatchAnalysisService service = new VideoBatchAnalysisService(
        VisionProcessingPipeline.passthrough(),
        new EveryNthFrameSampler(5),
        new FrameDifferenceMotionAnalyzer(25, 0.03f),
        objectDetector,
        null
);

try {
    service.analyze(source, sink);
} finally {
    source.close();
    sink.close();
}
```

Damit kann AskAI z.B. 25-fps-Video nur mit 5 fps analysieren, ohne die Wiedergabe-/Decodierlogik mit der AI zu koppeln.

## Integration in AskAI – empfohlene Reihenfolge für Claude

1. **XIAO Live-Stream integrieren.** `http://xiao-setup.local:81/stream` über `MjpegHttpFrameSource` öffnen und Frames in AskAI anzeigen. Keine AI in diesem Slice.
2. Modul als `vision-processing` in `settings.gradle` aufnehmen. Java 8 beibehalten.
3. Eine AskAI-UI für Videoquelle + Vorschau einführen. UI hängt vom Use Case/Service ab, nicht von JCodec oder MJPEG-Parsern.
4. `VisionProcessingPipeline` wie die Audio-DSP-Pipeline als konfigurierbare Blockkette darstellen. Profile/Registry erst ergänzen, wenn die ersten Blöcke produktiv funktionieren.
5. Batch-Dateiverarbeitung über `JCodecVideoFileFrameSource` anbinden. Quelle bleibt über `VideoFrameSource` austauschbar.
6. Modell-Capabilities sauber erweitern: `OBJECT_DETECTION` und `IMAGE_CLASSIFICATION` nicht mit Ollamas bestehendem `vision`-Token gleichsetzen.
7. Einen `ObjectDetector`-Adapter für die lokale AI-Runtime bauen. Bevorzugt kleine ONNX-Detectoren (YOLOv8n/YOLO11n) über DirectML. Kein ONNX Runtime in das Java-8-Hostmodul ziehen.
8. Erst danach optional `ImageClassifier` implementieren.
9. VLM/Ollama als **zusätzliche** Analyse nach Detection anbieten, etwa für ausgewählte Frames/ROIs. Nicht jeden Videoframe an ein GGUF-VLM schicken.
10. Später Audio- und Vision-Ergebnisse über gemeinsame Zeitstempel fusionieren (STT/DSP + Detection/Tracking).

## AskAI-/Architekturregeln

- Java 8 im Hostmodul.
- Keine UI-Abhängigkeit im Domain-/Processing-Modul.
- Keine direkte Ollama-Abhängigkeit in `vision-processing`.
- Keine ONNX-Runtime-Abhängigkeit in `vision-processing`.
- Runtime über Interfaces (`ObjectDetector`, `ImageClassifier`) injizieren.
- JCodec ausschließlich in `infrastructure` halten.
- Verarbeitungsblöcke klein und einzeln testbar halten.
- Keine implizite Größenänderung in der Pipeline; Resize nur durch expliziten `ResizeProcessor`.
- AI nicht als Bildfilter modellieren: Detection erzeugt Erkenntnisse und verändert nicht das Bild.

## Bezug zur vorhandenen Audio-Pipeline

Die Struktur spiegelt bewusst `audio-dsp`:

```text
AudioSource / PCM -> Audio processing blocks -> AI/STT hand-off
VideoFrameSource  -> Vision processing blocks -> AI detector/classifier hand-off
```

Die Vision-Pipeline soll die Audio-Pipeline nicht ersetzen oder mit ihr verschmelzen. Eine spätere Media-/Timeline-Schicht kann beide Resultate zusammenführen.

## Build

Standalone:

```bash
./gradlew test
```

Nach Integration in AskAI:

```bash
./gradlew :vision-processing:test
```

Dependencies:

- JCodec `0.2.5`
- JCodec JavaSE `0.2.5`
- JUnit `4.13.2` nur für Tests

## Was bewusst noch fehlt

- konkreter DirectML-/ONNX-Inferenzadapter
- Tracking (z.B. ByteTrack-artig)
- OCR
- Segmentierung
- Face recognition
- Batch-Audio/Video-Timeline-Fusion
- UI/Profile-Registry analog zur ausgebauten Audio-DSP-Registry

Diese Funktionen sollen auf den vorhandenen Ports aufbauen und nicht in den ersten Integrationsslice gedrückt werden.

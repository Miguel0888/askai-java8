package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;
import org.junit.Test;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import static org.junit.Assert.*;

public class VisionProcessingPipelineTest {
    @Test public void appliesProcessorsInOrder() {
        VisionFrame frame = new VisionFrame(0, 0, new BufferedImage(20, 10, BufferedImage.TYPE_3BYTE_BGR));
        VisionProcessingPipeline pipeline = new VisionProcessingPipeline(Arrays.<VisionFrameProcessor>asList(new ResizeProcessor(8, 6), new GrayscaleProcessor()));
        VisionFrame processed = pipeline.process(frame);
        assertEquals(8, processed.getWidth());
        assertEquals(6, processed.getHeight());
        assertEquals(BufferedImage.TYPE_BYTE_GRAY, processed.getImage().getType());
    }
}

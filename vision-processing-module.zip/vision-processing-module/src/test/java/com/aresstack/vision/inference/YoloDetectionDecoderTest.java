package com.aresstack.vision.inference;

import com.aresstack.vision.domain.Detection;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class YoloDetectionDecoderTest {
    @Test public void decodesOneYoloV8Candidate() {
        TensorImage input = new TensorImage(new float[0], 640, 640, 1f, 0f, 0f, 640, 640);
        float[] output = new float[84];
        output[0] = 320; output[1] = 320; output[2] = 100; output[3] = 80;
        output[4 + 2] = 0.9f;
        List<Detection> detections = new YoloDetectionDecoder(0.5f, 0.45f).decodeYoloV8(output, 84, 1, false, input);
        assertEquals(1, detections.size());
        assertEquals("car", detections.get(0).getLabel());
        assertEquals(270f, detections.get(0).getBox().getX(), 0.01f);
    }
}

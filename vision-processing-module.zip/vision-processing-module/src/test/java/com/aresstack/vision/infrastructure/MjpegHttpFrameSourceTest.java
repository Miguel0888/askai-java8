package com.aresstack.vision.infrastructure;

import com.aresstack.vision.domain.VisionFrame;
import com.sun.net.httpserver.HttpServer;
import org.junit.Test;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class MjpegHttpFrameSourceTest {
    @Test
    public void readsJpegFrameFromMultipartStream() throws Exception {
        final byte[] jpeg = createJpeg();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/stream", exchange -> {
            exchange.getResponseHeaders().set("Content-Type", "multipart/x-mixed-replace; boundary=frame");
            exchange.sendResponseHeaders(200, 0);
            OutputStream output = exchange.getResponseBody();
            try {
                output.write("--frame\r\nContent-Type: image/jpeg\r\n\r\n".getBytes("US-ASCII"));
                output.write(jpeg);
                output.write("\r\n--frame--\r\n".getBytes("US-ASCII"));
            } finally {
                output.close();
            }
        });
        server.start();

        MjpegHttpFrameSource source = new MjpegHttpFrameSource(
                "http://127.0.0.1:" + server.getAddress().getPort() + "/stream");
        try {
            VisionFrame frame = source.readNext();
            assertNotNull(frame);
            assertEquals(12, frame.getWidth());
            assertEquals(8, frame.getHeight());
        } finally {
            source.close();
            server.stop(0);
        }
    }

    private static byte[] createJpeg() throws Exception {
        BufferedImage image = new BufferedImage(12, 8, BufferedImage.TYPE_3BYTE_BGR);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ImageIO.write(image, "jpg", output);
        return output.toByteArray();
    }
}

package com.aresstack.vision.infrastructure;

import com.aresstack.vision.domain.VisionFrame;
import java.io.Closeable;
import java.io.IOException;

public interface VideoFrameSource extends Closeable {
    VisionFrame readNext() throws IOException;
}

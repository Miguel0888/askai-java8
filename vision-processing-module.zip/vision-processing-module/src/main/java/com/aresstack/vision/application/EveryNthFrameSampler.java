package com.aresstack.vision.application;

import com.aresstack.vision.domain.VisionFrame;

public final class EveryNthFrameSampler implements FrameSampler {
    private final int step;
    public EveryNthFrameSampler(int step) {
        if (step <= 0) throw new IllegalArgumentException("Step must be positive.");
        this.step = step;
    }
    @Override public boolean accept(VisionFrame frame) { return frame.getIndex() % step == 0; }
}

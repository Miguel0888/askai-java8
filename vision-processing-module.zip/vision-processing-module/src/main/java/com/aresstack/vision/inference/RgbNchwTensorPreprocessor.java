package com.aresstack.vision.inference;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public final class RgbNchwTensorPreprocessor {
    private final int targetWidth;
    private final int targetHeight;

    public RgbNchwTensorPreprocessor(int targetWidth, int targetHeight) {
        if (targetWidth <= 0 || targetHeight <= 0) throw new IllegalArgumentException("Target size must be positive.");
        this.targetWidth = targetWidth; this.targetHeight = targetHeight;
    }

    public TensorImage preprocess(BufferedImage source) {
        float scale = Math.min((float) targetWidth / source.getWidth(), (float) targetHeight / source.getHeight());
        int scaledWidth = Math.max(1, Math.round(source.getWidth() * scale));
        int scaledHeight = Math.max(1, Math.round(source.getHeight() * scale));
        int padX = (targetWidth - scaledWidth) / 2;
        int padY = (targetHeight - scaledHeight) / 2;
        BufferedImage canvas = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D graphics = canvas.createGraphics();
        try {
            graphics.fillRect(0, 0, targetWidth, targetHeight);
            graphics.drawImage(source, padX, padY, scaledWidth, scaledHeight, null);
        } finally { graphics.dispose(); }
        int plane = targetWidth * targetHeight;
        float[] data = new float[plane * 3];
        for (int y = 0; y < targetHeight; y++) {
            for (int x = 0; x < targetWidth; x++) {
                int rgb = canvas.getRGB(x, y);
                int offset = y * targetWidth + x;
                data[offset] = ((rgb >> 16) & 0xff) / 255f;
                data[plane + offset] = ((rgb >> 8) & 0xff) / 255f;
                data[2 * plane + offset] = (rgb & 0xff) / 255f;
            }
        }
        return new TensorImage(data, targetWidth, targetHeight, scale, padX, padY, source.getWidth(), source.getHeight());
    }
}

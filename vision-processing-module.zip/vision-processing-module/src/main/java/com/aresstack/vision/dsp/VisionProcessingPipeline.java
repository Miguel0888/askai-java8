package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class VisionProcessingPipeline {
    private final List<VisionFrameProcessor> processors;

    public VisionProcessingPipeline(List<VisionFrameProcessor> processors) {
        if (processors == null) throw new IllegalArgumentException("Processors must not be null.");
        this.processors = Collections.unmodifiableList(new ArrayList<VisionFrameProcessor>(processors));
    }

    public VisionFrame process(VisionFrame frame) {
        if (frame == null) throw new IllegalArgumentException("Frame must not be null.");
        VisionFrame current = frame;
        for (VisionFrameProcessor processor : processors) current = processor.process(current);
        return current;
    }

    public static VisionProcessingPipeline passthrough() {
        return new VisionProcessingPipeline(Collections.<VisionFrameProcessor>emptyList());
    }
}

package com.aresstack.vision.inference;

import com.aresstack.vision.domain.Detection;
import com.aresstack.vision.domain.VisionFrame;
import java.util.List;

public interface ObjectDetector {
    List<Detection> detect(VisionFrame frame) throws VisionInferenceException;
}

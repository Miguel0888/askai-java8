package com.aresstack.vision.inference;

public final class TensorImage {
    private final float[] data;
    private final int width;
    private final int height;
    private final float scale;
    private final float padX;
    private final float padY;
    private final int sourceWidth;
    private final int sourceHeight;

    public TensorImage(float[] data, int width, int height, float scale, float padX, float padY,
                       int sourceWidth, int sourceHeight) {
        this.data = data; this.width = width; this.height = height; this.scale = scale;
        this.padX = padX; this.padY = padY; this.sourceWidth = sourceWidth; this.sourceHeight = sourceHeight;
    }

    public float[] getData() { return data; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public float getScale() { return scale; }
    public float getPadX() { return padX; }
    public float getPadY() { return padY; }
    public int getSourceWidth() { return sourceWidth; }
    public int getSourceHeight() { return sourceHeight; }
}

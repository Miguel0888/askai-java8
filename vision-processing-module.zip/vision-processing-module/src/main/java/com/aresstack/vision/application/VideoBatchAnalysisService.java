package com.aresstack.vision.application;

import com.aresstack.vision.domain.*;
import com.aresstack.vision.dsp.FrameDifferenceMotionAnalyzer;
import com.aresstack.vision.dsp.VisionProcessingPipeline;
import com.aresstack.vision.inference.*;
import com.aresstack.vision.infrastructure.VideoFrameSource;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public final class VideoBatchAnalysisService {
    private final VisionProcessingPipeline processingPipeline;
    private final FrameSampler sampler;
    private final FrameDifferenceMotionAnalyzer motionAnalyzer;
    private final ObjectDetector detector;
    private final ImageClassifier classifier;

    public VideoBatchAnalysisService(VisionProcessingPipeline processingPipeline, FrameSampler sampler,
                                     FrameDifferenceMotionAnalyzer motionAnalyzer, ObjectDetector detector,
                                     ImageClassifier classifier) {
        if (processingPipeline == null) throw new IllegalArgumentException("Processing pipeline must not be null.");
        if (sampler == null) throw new IllegalArgumentException("Sampler must not be null.");
        this.processingPipeline = processingPipeline;
        this.sampler = sampler;
        this.motionAnalyzer = motionAnalyzer;
        this.detector = detector;
        this.classifier = classifier;
    }

    public long analyze(VideoFrameSource source, VideoAnalysisResultSink sink) throws IOException, VisionInferenceException {
        if (source == null || sink == null) throw new IllegalArgumentException("Source and sink must not be null.");
        long analyzed = 0;
        VisionFrame frame;
        while ((frame = source.readNext()) != null) {
            if (!sampler.accept(frame)) continue;
            VisionFrame processed = processingPipeline.process(frame);
            MotionAnalysis motion = motionAnalyzer == null ? null : motionAnalyzer.analyze(processed);
            List<Detection> detections = detector == null ? Collections.<Detection>emptyList() : detector.detect(processed);
            List<Classification> classifications = classifier == null ? Collections.<Classification>emptyList() : classifier.classify(processed);
            sink.accept(new VideoAnalysisResult(processed, motion, detections, classifications));
            analyzed++;
        }
        return analyzed;
    }
}

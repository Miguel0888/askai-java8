package com.aresstack.vision.domain;

import java.awt.image.BufferedImage;

public final class VisionFrame {
    private final long index;
    private final long timestampMicros;
    private final BufferedImage image;

    public VisionFrame(long index, long timestampMicros, BufferedImage image) {
        if (index < 0) throw new IllegalArgumentException("Frame index must not be negative.");
        if (timestampMicros < 0) throw new IllegalArgumentException("Timestamp must not be negative.");
        if (image == null) throw new IllegalArgumentException("Image must not be null.");
        this.index = index;
        this.timestampMicros = timestampMicros;
        this.image = image;
    }

    public long getIndex() { return index; }
    public long getTimestampMicros() { return timestampMicros; }
    public BufferedImage getImage() { return image; }
    public int getWidth() { return image.getWidth(); }
    public int getHeight() { return image.getHeight(); }

    public VisionFrame withImage(BufferedImage newImage) {
        return new VisionFrame(index, timestampMicros, newImage);
    }
}

package com.aresstack.vision.demo;

import com.aresstack.vision.domain.VisionFrame;
import com.aresstack.vision.infrastructure.MjpegHttpFrameSource;
import javax.imageio.ImageIO;
import java.io.File;

public final class CameraStreamProbe {
    private CameraStreamProbe() { }

    public static void main(String[] args) throws Exception {
        String url = args.length > 0 ? args[0] : MjpegHttpFrameSource.DEFAULT_XIAO_URL;
        System.out.println("Connecting to MJPEG camera: " + url);
        MjpegHttpFrameSource source = new MjpegHttpFrameSource(url);
        try {
            VisionFrame frame = source.readNext();
            if (frame == null) throw new IllegalStateException("Camera stream ended before the first frame.");
            File output = new File("camera-probe.jpg");
            ImageIO.write(frame.getImage(), "jpg", output);
            System.out.println("Frame received: " + frame.getWidth() + "x" + frame.getHeight());
            System.out.println("Saved: " + output.getAbsolutePath());
        } finally { source.close(); }
    }
}

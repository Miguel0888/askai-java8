package com.aresstack.vision.domain;

public final class Classification {
    private final int classId;
    private final String label;
    private final float confidence;

    public Classification(int classId, String label, float confidence) {
        this.classId = classId;
        this.label = label == null ? String.valueOf(classId) : label;
        this.confidence = confidence;
    }

    public int getClassId() { return classId; }
    public String getLabel() { return label; }
    public float getConfidence() { return confidence; }
}

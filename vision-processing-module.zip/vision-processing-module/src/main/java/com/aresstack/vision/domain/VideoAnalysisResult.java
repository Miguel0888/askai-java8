package com.aresstack.vision.domain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class VideoAnalysisResult {
    private final VisionFrame frame;
    private final MotionAnalysis motion;
    private final List<Detection> detections;
    private final List<Classification> classifications;

    public VideoAnalysisResult(VisionFrame frame, MotionAnalysis motion,
                               List<Detection> detections, List<Classification> classifications) {
        if (frame == null) throw new IllegalArgumentException("Frame must not be null.");
        this.frame = frame;
        this.motion = motion;
        this.detections = immutableCopy(detections);
        this.classifications = immutableCopy(classifications);
    }

    private static <T> List<T> immutableCopy(List<T> values) {
        if (values == null || values.isEmpty()) return Collections.emptyList();
        return Collections.unmodifiableList(new ArrayList<T>(values));
    }

    public VisionFrame getFrame() { return frame; }
    public MotionAnalysis getMotion() { return motion; }
    public List<Detection> getDetections() { return detections; }
    public List<Classification> getClassifications() { return classifications; }
}

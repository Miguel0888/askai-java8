package com.aresstack.vision.infrastructure;

import com.aresstack.vision.domain.VisionFrame;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public final class MjpegHttpFrameSource implements VideoFrameSource {
    public static final String DEFAULT_XIAO_URL = "http://xiao-setup.local:81/stream";
    private static final int MAX_JPEG_BYTES = 8 * 1024 * 1024;

    private final HttpURLConnection connection;
    private final InputStream input;
    private final long openedAtNanos;
    private long frameIndex;

    public MjpegHttpFrameSource(String streamUrl) throws IOException {
        if (streamUrl == null || streamUrl.trim().isEmpty()) throw new IllegalArgumentException("Stream URL must not be empty.");
        connection = (HttpURLConnection) new URL(streamUrl).openConnection();
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(15000);
        connection.setUseCaches(false);
        connection.setRequestProperty("Accept", "multipart/x-mixed-replace,image/jpeg,*/*");
        connection.connect();
        int code = connection.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("MJPEG endpoint returned HTTP " + code + ".");
        input = connection.getInputStream();
        openedAtNanos = System.nanoTime();
    }

    @Override
    public VisionFrame readNext() throws IOException {
        byte[] jpeg = readJpeg();
        if (jpeg == null) return null;
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(jpeg));
        if (image == null) throw new IOException("MJPEG stream contained an undecodable JPEG frame.");
        long timestampMicros = (System.nanoTime() - openedAtNanos) / 1000L;
        return new VisionFrame(frameIndex++, timestampMicros, image);
    }

    private byte[] readJpeg() throws IOException {
        int previous = -1;
        int current;
        while ((current = input.read()) >= 0) {
            if (previous == 0xff && current == 0xd8) break;
            previous = current;
        }
        if (current < 0) return null;
        ByteArrayOutputStream jpeg = new ByteArrayOutputStream(128 * 1024);
        jpeg.write(0xff); jpeg.write(0xd8);
        previous = -1;
        while ((current = input.read()) >= 0) {
            jpeg.write(current);
            if (previous == 0xff && current == 0xd9) return jpeg.toByteArray();
            if (jpeg.size() > MAX_JPEG_BYTES) throw new IOException("MJPEG frame exceeded safety limit of " + MAX_JPEG_BYTES + " bytes.");
            previous = current;
        }
        throw new IOException("MJPEG stream ended inside a JPEG frame.");
    }

    @Override
    public void close() throws IOException {
        try { input.close(); } finally { connection.disconnect(); }
    }
}

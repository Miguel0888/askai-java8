package com.aresstack.vision.inference;

import com.aresstack.vision.domain.Classification;
import com.aresstack.vision.domain.VisionFrame;
import java.util.List;

public interface ImageClassifier {
    List<Classification> classify(VisionFrame frame) throws VisionInferenceException;
}

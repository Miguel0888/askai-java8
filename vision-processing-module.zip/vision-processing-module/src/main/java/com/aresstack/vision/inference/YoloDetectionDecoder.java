package com.aresstack.vision.inference;

import com.aresstack.vision.domain.BoundingBox;
import com.aresstack.vision.domain.Detection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public final class YoloDetectionDecoder {
    private final float confidenceThreshold;
    private final float iouThreshold;

    public YoloDetectionDecoder(float confidenceThreshold, float iouThreshold) {
        this.confidenceThreshold = confidenceThreshold;
        this.iouThreshold = iouThreshold;
    }

    public List<Detection> decodeYoloV8(float[] output, int attributes, int candidates, boolean attributesFirst, TensorImage input) {
        if (attributes < 5) throw new IllegalArgumentException("YOLO output needs at least five attributes.");
        List<Detection> detections = new ArrayList<Detection>();
        int classCount = attributes - 4;
        for (int candidate = 0; candidate < candidates; candidate++) {
            float cx = value(output, attributes, candidates, attributesFirst, candidate, 0);
            float cy = value(output, attributes, candidates, attributesFirst, candidate, 1);
            float w = value(output, attributes, candidates, attributesFirst, candidate, 2);
            float h = value(output, attributes, candidates, attributesFirst, candidate, 3);
            int classId = -1;
            float best = Float.NEGATIVE_INFINITY;
            for (int c = 0; c < classCount; c++) {
                float score = value(output, attributes, candidates, attributesFirst, candidate, 4 + c);
                if (score > best) { best = score; classId = c; }
            }
            if (best < confidenceThreshold) continue;
            detections.add(new Detection(classId, Coco80Labels.label(classId), best,
                    mapBox(cx - w / 2f, cy - h / 2f, w, h, input)));
        }
        return nonMaximumSuppression(detections);
    }

    private static float value(float[] output, int attributes, int candidates, boolean attributesFirst, int candidate, int attribute) {
        int index = attributesFirst ? attribute * candidates + candidate : candidate * attributes + attribute;
        return output[index];
    }

    private static BoundingBox mapBox(float x, float y, float width, float height, TensorImage input) {
        float sx = (x - input.getPadX()) / input.getScale();
        float sy = (y - input.getPadY()) / input.getScale();
        float sw = width / input.getScale();
        float sh = height / input.getScale();
        sx = clamp(sx, 0, input.getSourceWidth());
        sy = clamp(sy, 0, input.getSourceHeight());
        float right = clamp(sx + sw, 0, input.getSourceWidth());
        float bottom = clamp(sy + sh, 0, input.getSourceHeight());
        return new BoundingBox(sx, sy, Math.max(0, right - sx), Math.max(0, bottom - sy));
    }

    private List<Detection> nonMaximumSuppression(List<Detection> input) {
        Collections.sort(input, new Comparator<Detection>() {
            @Override public int compare(Detection a, Detection b) { return Float.compare(b.getConfidence(), a.getConfidence()); }
        });
        List<Detection> kept = new ArrayList<Detection>();
        for (Detection candidate : input) {
            boolean suppressed = false;
            for (Detection selected : kept) {
                if (candidate.getClassId() == selected.getClassId() && iou(candidate.getBox(), selected.getBox()) >= iouThreshold) {
                    suppressed = true; break;
                }
            }
            if (!suppressed) kept.add(candidate);
        }
        return kept;
    }

    private static float iou(BoundingBox a, BoundingBox b) {
        float left = Math.max(a.getX(), b.getX());
        float top = Math.max(a.getY(), b.getY());
        float right = Math.min(a.getRight(), b.getRight());
        float bottom = Math.min(a.getBottom(), b.getBottom());
        float intersection = Math.max(0, right - left) * Math.max(0, bottom - top);
        float union = a.area() + b.area() - intersection;
        return union <= 0 ? 0 : intersection / union;
    }

    private static float clamp(float value, float min, float max) { return Math.max(min, Math.min(max, value)); }
}

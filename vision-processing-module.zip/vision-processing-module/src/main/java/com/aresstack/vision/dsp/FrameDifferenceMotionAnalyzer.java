package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.MotionAnalysis;
import com.aresstack.vision.domain.VisionFrame;
import java.awt.image.BufferedImage;

public final class FrameDifferenceMotionAnalyzer {
    private final int pixelDifferenceThreshold;
    private final float changedPixelRatioThreshold;
    private BufferedImage previous;

    public FrameDifferenceMotionAnalyzer(int pixelDifferenceThreshold, float changedPixelRatioThreshold) {
        if (pixelDifferenceThreshold < 0) throw new IllegalArgumentException("Pixel threshold must not be negative.");
        if (changedPixelRatioThreshold < 0 || changedPixelRatioThreshold > 1) throw new IllegalArgumentException("Ratio threshold must be between 0 and 1.");
        this.pixelDifferenceThreshold = pixelDifferenceThreshold;
        this.changedPixelRatioThreshold = changedPixelRatioThreshold;
    }

    public synchronized MotionAnalysis analyze(VisionFrame frame) {
        BufferedImage current = frame.getImage();
        if (previous == null || previous.getWidth() != current.getWidth() || previous.getHeight() != current.getHeight()) {
            previous = copy(current);
            return new MotionAnalysis(0f, false);
        }
        int changed = 0;
        int total = current.getWidth() * current.getHeight();
        for (int y = 0; y < current.getHeight(); y += 2) {
            for (int x = 0; x < current.getWidth(); x += 2) {
                int a = previous.getRGB(x, y);
                int b = current.getRGB(x, y);
                int diff = channelDifference(a, b);
                if (diff >= pixelDifferenceThreshold) changed++;
            }
        }
        int sampled = ((current.getWidth() + 1) / 2) * ((current.getHeight() + 1) / 2);
        float ratio = sampled == 0 ? 0f : (float) changed / sampled;
        previous = copy(current);
        return new MotionAnalysis(ratio, ratio >= changedPixelRatioThreshold);
    }

    private static int channelDifference(int a, int b) {
        int dr = Math.abs(((a >> 16) & 0xff) - ((b >> 16) & 0xff));
        int dg = Math.abs(((a >> 8) & 0xff) - ((b >> 8) & 0xff));
        int db = Math.abs((a & 0xff) - (b & 0xff));
        return Math.max(dr, Math.max(dg, db));
    }

    private static BufferedImage copy(BufferedImage source) {
        BufferedImage copy = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
        java.awt.Graphics2D graphics = copy.createGraphics();
        try {
            graphics.drawImage(source, 0, 0, null);
        } finally {
            graphics.dispose();
        }
        return copy;
    }
}

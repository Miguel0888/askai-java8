package com.aresstack.vision.infrastructure;

import com.aresstack.vision.application.VideoAnalysisResultSink;
import com.aresstack.vision.domain.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class JsonLinesResultSink implements VideoAnalysisResultSink {
    private final Writer writer;

    public JsonLinesResultSink(File file) throws IOException {
        writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
    }

    @Override public synchronized void accept(VideoAnalysisResult result) throws IOException {
        StringBuilder json = new StringBuilder(512);
        json.append('{').append("\"frame\":").append(result.getFrame().getIndex())
            .append(",\"timestampMicros\":").append(result.getFrame().getTimestampMicros());
        if (result.getMotion() != null) {
            json.append(",\"motion\":{").append("\"ratio\":").append(result.getMotion().getChangedPixelRatio())
                .append(",\"detected\":").append(result.getMotion().isMotionDetected()).append('}');
        }
        json.append(",\"detections\":[");
        for (int i = 0; i < result.getDetections().size(); i++) {
            if (i > 0) json.append(',');
            Detection d = result.getDetections().get(i); BoundingBox b = d.getBox();
            json.append('{').append("\"classId\":").append(d.getClassId())
                .append(",\"label\":\"").append(escape(d.getLabel())).append("\"")
                .append(",\"confidence\":").append(d.getConfidence())
                .append(",\"box\":{").append("\"x\":").append(b.getX()).append(",\"y\":").append(b.getY())
                .append(",\"width\":").append(b.getWidth()).append(",\"height\":").append(b.getHeight()).append("}}");
        }
        json.append("]}\n"); writer.write(json.toString()); writer.flush();
    }

    private static String escape(String value) { return value.replace("\\", "\\\\").replace("\"", "\\\""); }
    @Override public void close() throws IOException { writer.close(); }
}

package com.aresstack.vision.domain;

public final class Detection {
    private final int classId;
    private final String label;
    private final float confidence;
    private final BoundingBox box;

    public Detection(int classId, String label, float confidence, BoundingBox box) {
        if (box == null) throw new IllegalArgumentException("Bounding box must not be null.");
        this.classId = classId;
        this.label = label == null ? String.valueOf(classId) : label;
        this.confidence = confidence;
        this.box = box;
    }

    public int getClassId() { return classId; }
    public String getLabel() { return label; }
    public float getConfidence() { return confidence; }
    public BoundingBox getBox() { return box; }
}

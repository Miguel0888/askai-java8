package com.aresstack.vision.domain;

public final class MotionAnalysis {
    private final float changedPixelRatio;
    private final boolean motionDetected;

    public MotionAnalysis(float changedPixelRatio, boolean motionDetected) {
        this.changedPixelRatio = changedPixelRatio;
        this.motionDetected = motionDetected;
    }

    public float getChangedPixelRatio() { return changedPixelRatio; }
    public boolean isMotionDetected() { return motionDetected; }
}

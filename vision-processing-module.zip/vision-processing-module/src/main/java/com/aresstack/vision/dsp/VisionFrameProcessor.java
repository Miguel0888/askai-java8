package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;

public interface VisionFrameProcessor {
    VisionFrame process(VisionFrame frame);
}

package com.aresstack.vision.inference;

public final class VisionInferenceException extends Exception {
    public VisionInferenceException(String message) { super(message); }
    public VisionInferenceException(String message, Throwable cause) { super(message, cause); }
}

package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public final class ResizeProcessor implements VisionFrameProcessor {
    private final int width;
    private final int height;

    public ResizeProcessor(int width, int height) {
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("Target size must be positive.");
        this.width = width; this.height = height;
    }

    @Override
    public VisionFrame process(VisionFrame frame) {
        BufferedImage target = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
        Graphics2D graphics = target.createGraphics();
        try {
            // Prefer quality scaling for offline/batch processing.
            graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            graphics.drawImage(frame.getImage(), 0, 0, width, height, null);
        } finally {
            graphics.dispose();
        }
        return frame.withImage(target);
    }
}

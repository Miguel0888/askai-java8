package com.aresstack.vision.domain;

public final class BoundingBox {
    private final float x;
    private final float y;
    private final float width;
    private final float height;

    public BoundingBox(float x, float y, float width, float height) {
        if (width < 0 || height < 0) throw new IllegalArgumentException("Box size must not be negative.");
        this.x = x; this.y = y; this.width = width; this.height = height;
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public float getRight() { return x + width; }
    public float getBottom() { return y + height; }
    public float area() { return width * height; }
}

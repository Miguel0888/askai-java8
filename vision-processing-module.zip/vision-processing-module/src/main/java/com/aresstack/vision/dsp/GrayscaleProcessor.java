package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public final class GrayscaleProcessor implements VisionFrameProcessor {
    @Override
    public VisionFrame process(VisionFrame frame) {
        BufferedImage target = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D graphics = target.createGraphics();
        try { graphics.drawImage(frame.getImage(), 0, 0, null); }
        finally { graphics.dispose(); }
        return frame.withImage(target);
    }
}

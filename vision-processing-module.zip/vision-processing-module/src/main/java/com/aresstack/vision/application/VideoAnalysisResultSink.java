package com.aresstack.vision.application;

import com.aresstack.vision.domain.VideoAnalysisResult;
import java.io.Closeable;
import java.io.IOException;

public interface VideoAnalysisResultSink extends Closeable {
    void accept(VideoAnalysisResult result) throws IOException;
}

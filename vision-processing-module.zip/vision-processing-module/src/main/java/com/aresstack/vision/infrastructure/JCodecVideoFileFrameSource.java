package com.aresstack.vision.infrastructure;

import com.aresstack.vision.domain.VisionFrame;
import org.jcodec.api.FrameGrab;
import org.jcodec.api.JCodecException;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.common.model.Picture;
import org.jcodec.scale.AWTUtil;
import java.io.File;
import java.io.IOException;

public final class JCodecVideoFileFrameSource implements VideoFrameSource {
    private final SeekableByteChannel channel;
    private final FrameGrab grab;
    private long frameIndex;
    private final double frameRate;

    public JCodecVideoFileFrameSource(File file) throws IOException {
        if (file == null) throw new IllegalArgumentException("Video file must not be null.");
        try {
            channel = NIOUtils.readableChannel(file);
            grab = FrameGrab.createFrameGrab(channel);
            double duration = grab.getVideoTrack().getMeta().getTotalDuration();
            int frames = grab.getVideoTrack().getMeta().getTotalFrames();
            frameRate = duration > 0 && frames > 0 ? frames / duration : 0.0;
        } catch (JCodecException e) {
            throw new IOException("Unable to open video file with JCodec: " + file, e);
        }
    }

    @Override
    public VisionFrame readNext() throws IOException {
        Picture picture = grab.getNativeFrame();
        if (picture == null) return null;
        long timestampMicros = frameRate > 0 ? Math.round((frameIndex / frameRate) * 1000000.0) : frameIndex;
        return new VisionFrame(frameIndex++, timestampMicros, AWTUtil.toBufferedImage(picture));
    }

    @Override
    public void close() throws IOException { channel.close(); }
}

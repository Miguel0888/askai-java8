package com.aresstack.vision.application;

import com.aresstack.vision.domain.VisionFrame;

public interface FrameSampler {
    boolean accept(VisionFrame frame);
}

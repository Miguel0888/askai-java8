package com.aresstack.vision.dsp;

import com.aresstack.vision.domain.VisionFrame;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;

public final class ContrastProcessor implements VisionFrameProcessor {
    private final float scale;
    private final float offset;

    public ContrastProcessor(float scale, float offset) {
        this.scale = scale; this.offset = offset;
    }

    @Override
    public VisionFrame process(VisionFrame frame) {
        BufferedImage source = frame.getImage();
        BufferedImage target = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
        new RescaleOp(scale, offset, null).filter(source, target);
        return frame.withImage(target);
    }
}
